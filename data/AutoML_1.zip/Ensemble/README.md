# Summary of Ensemble

[<< Go back](../README.md)


## Ensemble structure
| Model          |   Weight |
|:---------------|---------:|
| 2_DecisionTree |        1 |

## Metric details
|           |     score |    threshold |
|:----------|----------:|-------------:|
| logloss   | 0.0272858 | nan          |
| auc       | 0.846658  | nan          |
| f1        | 0.330097  |   0.00241143 |
| accuracy  | 0.975149  |   0.00241143 |
| precision | 0.21519   |   0.00241143 |
| recall    | 1         |   0.00217028 |
| mcc       | 0.381837  |   0.00241143 |


## Metric details with threshold from accuracy metric
|           |     score |    threshold |
|:----------|----------:|-------------:|
| logloss   | 0.0272858 | nan          |
| auc       | 0.846658  | nan          |
| f1        | 0.330097  |   0.00241143 |
| accuracy  | 0.975149  |   0.00241143 |
| precision | 0.21519   |   0.00241143 |
| recall    | 0.708333  |   0.00241143 |
| mcc       | 0.381837  |   0.00241143 |


## Confusion matrix (at threshold=0.002411)
|              |   Predicted as 0 |   Predicted as 1 |
|:-------------|-----------------:|-----------------:|
| Labeled as 0 |             5381 |              124 |
| Labeled as 1 |               14 |               34 |

## Learning curves
![Learning curves](learning_curves.png)
## Confusion Matrix

![Confusion Matrix](confusion_matrix.png)


## Normalized Confusion Matrix

![Normalized Confusion Matrix](confusion_matrix_normalized.png)


## ROC Curve

![ROC Curve](roc_curve.png)


## Kolmogorov-Smirnov Statistic

![Kolmogorov-Smirnov Statistic](ks_statistic.png)


## Precision-Recall Curve

![Precision-Recall Curve](precision_recall_curve.png)


## Calibration Curve

![Calibration Curve](calibration_curve_curve.png)


## Cumulative Gains Curve

![Cumulative Gains Curve](cumulative_gains_curve.png)


## Lift Curve

![Lift Curve](lift_curve.png)



[<< Go back](../README.md)
